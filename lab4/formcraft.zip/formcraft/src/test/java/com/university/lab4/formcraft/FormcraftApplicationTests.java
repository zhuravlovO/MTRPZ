package com.university.lab4.formcraft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormcraftApplicationTests {

	@Test
	void contextLoads() {
	}

}
