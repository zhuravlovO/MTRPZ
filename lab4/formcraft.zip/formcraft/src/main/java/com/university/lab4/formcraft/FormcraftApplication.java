package com.university.lab4.formcraft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormcraftApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormcraftApplication.class, args);
	}

}
